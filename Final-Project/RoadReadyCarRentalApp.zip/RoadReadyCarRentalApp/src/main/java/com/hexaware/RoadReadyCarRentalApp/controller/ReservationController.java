package com.hexaware.RoadReadyCarRentalApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.ReservationDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Reservation.ReservationStatus;
import com.hexaware.RoadReadyCarRentalApp.service.ReservationService;

@RestController
@RequestMapping("/api/reservations")
@CrossOrigin("*")
public class ReservationController {

	@Autowired
	private ReservationService reservationService;

	// url = http//localhost:8080/api/reservations/make
	@PreAuthorize("hasRole('ROLE_USER')")
	@PostMapping("/make")
	public ResponseEntity<ReservationDTO> makeReservation(@RequestBody ReservationDTO reservation) throws ResourceNotFoundException, NoDataFoundException {
		ReservationDTO newReservation = reservationService.makeReservation(reservation);
		return ResponseEntity.ok(newReservation);
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/all")
	public ResponseEntity<List<ReservationDTO>> getAllReservations() throws NoDataFoundException {
	    List<ReservationDTO> reservations = reservationService.getAllReservations();
	    return ResponseEntity.ok(reservations);
	}


	// url = http//localhost:8080/api/reservations/getById/2
	@GetMapping("/getById/{id}")
	public ResponseEntity<ReservationDTO> getReservationById(@PathVariable Long id) throws ResourceNotFoundException {
		ReservationDTO reservation = reservationService.getReservationById(id);
		return ResponseEntity.ok(reservation);
	}

	// url = http//localhost:8080/api/reservations/user/2
	@GetMapping("/user/{userId}")
	public ResponseEntity<List<ReservationDTO>> getReservationsByUserId(@PathVariable Long userId) throws ResourceNotFoundException {
		List<ReservationDTO> reservations = reservationService.getReservationsByUserId(userId);
		return ResponseEntity.ok(reservations);
	}

	// url = http//localhost:8080/api/reservations/car/2
	@GetMapping("/car/{carId}")
	public ResponseEntity<List<ReservationDTO>> getReservationsByCarId(@PathVariable Long carId) throws ResourceNotFoundException {
		List<ReservationDTO> reservations = reservationService.getReservationsByCarId(carId);
		return ResponseEntity.ok(reservations);
	}

	// url = http//localhost:8080/api/reservations/delete/2
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> cancelReservation(@PathVariable Long id) throws ResourceNotFoundException {
		reservationService.cancelReservation(id);
		return ResponseEntity.noContent().build();
	}
	
	// url = http//localhost:8080/api/reservations/updateStatus/2
	@PutMapping("/updateStatus/{reservationId}")
    public ResponseEntity<String> updateReservationStatus(
            @PathVariable Long reservationId,
            @RequestParam ReservationStatus newStatus) throws ResourceNotFoundException {
        boolean updated = reservationService.updateReservationStatus(reservationId, newStatus);
        if (updated) {
            return ResponseEntity.ok("Reservation status updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation not found.");
        }
	}
}
