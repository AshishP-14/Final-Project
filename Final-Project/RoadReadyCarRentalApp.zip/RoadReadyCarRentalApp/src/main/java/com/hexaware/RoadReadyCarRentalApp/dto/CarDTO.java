package com.hexaware.RoadReadyCarRentalApp.dto;


import com.hexaware.RoadReadyCarRentalApp.entity.Car.CarType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.FuelType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.TransmissionType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CarDTO {
	
	private Long id;
	private String brand;
	private String model;
	private String color;
	private Double price;
	private Boolean availability;
	private String location;
	private String description;
	
	private FuelType fuelType;
	
	private TransmissionType transmissionType;

	private CarType carType;

	
}
