package com.hexaware.RoadReadyCarRentalApp.dto;

import java.time.LocalDateTime;

import com.hexaware.RoadReadyCarRentalApp.entity.Reservation.ReservationStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ReservationDTO {
	private Long id;
    private Long userId;
    private Long carId;
    private LocalDateTime pickupDateTime;
    private LocalDateTime dropOffDateTime;
    private LocalDateTime reservationDate;
    private ReservationStatus status;

}
