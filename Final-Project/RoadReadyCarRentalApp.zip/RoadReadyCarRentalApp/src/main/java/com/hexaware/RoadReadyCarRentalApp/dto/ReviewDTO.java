package com.hexaware.RoadReadyCarRentalApp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ReviewDTO {
	private Long id;
	private Integer rating;
	private String comment;
	private Long userId;
	private Long carId;
}
