package com.hexaware.RoadReadyCarRentalApp.service;

import com.hexaware.RoadReadyCarRentalApp.dto.LoginDto;
import com.hexaware.RoadReadyCarRentalApp.dto.RegisterDto;
import com.hexaware.RoadReadyCarRentalApp.dto.UserDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.AuthenticationResponse;


public interface AuthenticationService {
//	public String register(UserDTO dto);
	public AuthenticationResponse authenticate(LoginDto dto); //login
	String register(RegisterDto request);
}
