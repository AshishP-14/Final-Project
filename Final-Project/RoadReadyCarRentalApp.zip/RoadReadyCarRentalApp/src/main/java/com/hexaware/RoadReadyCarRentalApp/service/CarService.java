package com.hexaware.RoadReadyCarRentalApp.service;

import java.util.List;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.CarDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.CarType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.FuelType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.TransmissionType;

public interface CarService {
	List<CarDTO> getAllCars() throws NoDataFoundException;

	CarDTO getCarById(Long id) throws ResourceNotFoundException;

	CarDTO createCar(CarDTO carDTO);

	CarDTO updateCar(Long id, CarDTO carDTO) throws ResourceNotFoundException;

	boolean deleteCar(Long id) throws NoDataFoundException;
	
	
	
	List<CarDTO> searchCarsByLocationAndAvailability(String location, boolean availability) throws NoDataFoundException;
    
	List<CarDTO> searchCarsByCarTypeAndAvailability(CarType carType, boolean availability) throws NoDataFoundException;
    
	List<CarDTO> searchCarsByLocationAndCarTypeAndAvailability(String location, CarType carType, boolean availability) throws NoDataFoundException;

	List<CarDTO> searchCarsByBrand(String brand) throws ResourceNotFoundException;
	List<CarDTO> searchCarsByModel(String model) throws ResourceNotFoundException;
    List<CarDTO> searchCarsByColor(String color) throws ResourceNotFoundException;
    List<CarDTO> searchCarsByAvailability(boolean availability) throws ResourceNotFoundException;
    List<CarDTO> searchCarsByPriceBetween(double minPrice, double maxPrice) throws NoDataFoundException;
    List<CarDTO> searchCarsByBrandAndColorAndAvailability(String brand, String color, boolean availability) throws NoDataFoundException;
    List<CarDTO> searchCarsByPriceLessThan(double price) throws NoDataFoundException;
    List<CarDTO> searchCarsByPriceGreaterThan(double price) throws NoDataFoundException;
    List<CarDTO> searchCarsByTransmissionTypeAndAvailability(TransmissionType transmissionType, boolean availability) throws NoDataFoundException;
    List<CarDTO> searchCarsByFuelTypeAndAvailability(FuelType fuelType, boolean availability) throws NoDataFoundException;
    
    List<CarDTO> searchCarsByBrandAndPriceBetween(String brand, double minPrice, double maxPrice) throws NoDataFoundException;
    List<CarDTO> searchCarsByLocationAndTransmissionTypeAndAvailability(String location,TransmissionType transmissionType, boolean availability) throws NoDataFoundException;

    // for sorting and filetring
	List<CarDTO> getAllSortedCars(String sortBy);
//	List<CarDTO> getAllFilteredCars(Boolean filterByAvailable);

//	public List<CarDTO> getFilteredAndSortedCars(String sortBy, boolean available);

//	List<CarDTO> getFilteredAndSortedCars(String sortBy, boolean availability, List<String> carTypes);
	
//	List<CarDTO> getFilteredAndSortedCars(String sortBy, boolean availability, List<String> filterByCarType,
//			List<String> filterByFuelType, List<String> filterByTransmissionType);

	List<CarDTO> getFilteredAndSortedCars(String sortBy, boolean availability, List<String> filterByCarType,
			List<String> filterByFuelType, List<String> filterByTransmissionType, String location);
	
}
