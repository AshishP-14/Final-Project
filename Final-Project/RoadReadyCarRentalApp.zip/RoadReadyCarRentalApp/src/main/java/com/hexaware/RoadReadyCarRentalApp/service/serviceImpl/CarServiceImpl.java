package com.hexaware.RoadReadyCarRentalApp.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.CarDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Car;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.CarType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.FuelType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.TransmissionType;
import com.hexaware.RoadReadyCarRentalApp.repository.CarRepository;
import com.hexaware.RoadReadyCarRentalApp.service.CarService;

@Service
public class CarServiceImpl implements CarService {

	private static final Logger logger = LoggerFactory.getLogger(CarServiceImpl.class);

	@Autowired
	private CarRepository carRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public List<CarDTO> getAllCars() throws NoDataFoundException {
		logger.info("Fetching all cars");
		List<Car> carsList = carRepository.findAll();

		if (carsList.isEmpty()) {
			logger.error("No cars found");
			throw new NoDataFoundException("No cars found");
		}

		List<CarDTO> carDTOList = new ArrayList<>();
		for (Car car : carsList) {
			carDTOList.add(modelMapper.map(car, CarDTO.class));
		}
		logger.info("Fetched cars: {}", carDTOList.size());
		return carDTOList;
	}

	@Override
	public CarDTO getCarById(Long id) throws ResourceNotFoundException {
		logger.info("Fetching car by ID: {}", id);
		Car car = carRepository.findById(id).orElseThrow(() -> {
			logger.error("Car not found with ID: {}", id);
			return new ResourceNotFoundException("Car", "id", id);
		});
		logger.debug("Fetched car: {}", car);
		return modelMapper.map(car, CarDTO.class);
	}

	@Override
	public CarDTO createCar(CarDTO carDto) {
		logger.info("Creating car with DTO: {}", carDto);
		Car car = modelMapper.map(carDto, Car.class);
		Car savedCar = carRepository.save(car);
		logger.debug("Car created successfully with ID: {}", savedCar.getId());
		return modelMapper.map(savedCar, CarDTO.class);
	}

	@Override
	public CarDTO updateCar(Long id, CarDTO carDto) throws ResourceNotFoundException {
		logger.info("Updating car with ID: {}", id);
		Car existingCar = carRepository.findById(id).orElseThrow(() -> {
			logger.error("Car not found with ID: {}", id);
			return new ResourceNotFoundException("Car", "id", id);
		});

		existingCar.setBrand(carDto.getBrand());
		existingCar.setModel(carDto.getModel());
		existingCar.setLocation(carDto.getLocation());
		existingCar.setPrice(carDto.getPrice());
		existingCar.setAvailability(carDto.getAvailability());
		existingCar.setColor(carDto.getColor());
		existingCar.setCarType(carDto.getCarType());
		existingCar.setDescription(carDto.getDescription());
		existingCar.setFuelType(carDto.getFuelType());
		existingCar.setTransmissionType(carDto.getTransmissionType());

		Car updatedCar = carRepository.save(existingCar);
		logger.debug("Car updated successfully: {}", updatedCar);
		return modelMapper.map(updatedCar, CarDTO.class);
	}

	@Override
	public boolean deleteCar(Long id) throws NoDataFoundException {
		logger.info("Deleting car with ID: {}", id);
		boolean isDeleted = false;
		if (carRepository.existsById(id)) {
			carRepository.deleteById(id);
			isDeleted = true;
			logger.debug("Car deleted successfully with ID: {}", id);
		} else {
			logger.error("Car not found with ID: {}", id);
			throw new NoDataFoundException("No cars found.");
		}
		return isDeleted;
	}

	@Override
	public List<CarDTO> searchCarsByLocationAndAvailability(String location, boolean availability)
			throws NoDataFoundException {
		logger.info("Searching cars by location: {} and availability: {}", location, availability);
		List<Car> availableCarList = carRepository.findByLocationAndAvailability(location, availability);
		if (availableCarList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException(
					"No cars found with location: " + location + " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", availableCarList.size());
		return mapCarEntitiesToDTOs(availableCarList);
	}

	@Override
	public List<CarDTO> searchCarsByCarTypeAndAvailability(CarType carType, boolean availability)
			throws NoDataFoundException {
		logger.info("Searching cars by car type: {} and availability: {}", carType, availability);
		List<Car> availableCarList = carRepository.findByCarTypeAndAvailability(carType, availability);
		if (availableCarList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException("No cars found with CarType: " + carType + " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", availableCarList.size());
		return mapCarEntitiesToDTOs(availableCarList);
	}

	@Override
	public List<CarDTO> searchCarsByLocationAndCarTypeAndAvailability(String location, CarType carType,
			boolean availability) throws NoDataFoundException {
		logger.info("Searching cars by location: {}, car type: {} and availability: {}", location, carType,
				availability);
		List<Car> availableCarList = carRepository.findByLocationAndCarTypeAndAvailability(location, carType,
				availability);
		if (availableCarList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException("No Cars found with location: " + location + " CarType: " + carType
					+ " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", availableCarList.size());
		return mapCarEntitiesToDTOs(availableCarList);
	}

	@Override
	public List<CarDTO> searchCarsByBrand(String brand) throws ResourceNotFoundException {
		logger.info("Searching cars by brand: {}", brand);
		List<Car> carsList = carRepository.findByBrand(brand);
		if (carsList.isEmpty()) {
			logger.error("Car not found with Brand: {}", brand);
			throw new ResourceNotFoundException("Car", "brand", brand);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByModel(String model) throws ResourceNotFoundException {
		logger.info("Searching cars by model: {}", model);
		List<Car> carsList = carRepository.findByModel(model);
		if (carsList.isEmpty()) {
			logger.error("Car not found with model: {}", model);
			throw new ResourceNotFoundException("Car", "model", model);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByColor(String color) throws ResourceNotFoundException {
		logger.info("Searching cars by color: {}", color);
		List<Car> carsList = carRepository.findByColor(color);
		if (carsList.isEmpty()) {
			logger.error("Car not found with color: {}", color);
			throw new ResourceNotFoundException("Car", "color", color);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByAvailability(boolean availability) throws ResourceNotFoundException {
		logger.info("Searching cars by availability: {}", availability);
		List<Car> carsList = carRepository.findByAvailability(availability);
		if (carsList.isEmpty()) {
			logger.error("Car not found with availability: {}", availability);
			throw new ResourceNotFoundException("Car", "availability", String.valueOf(availability));
		}
		logger.info("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByPriceBetween(double minPrice, double maxPrice) throws NoDataFoundException {
		logger.info("Searching cars by price between {} and {}", minPrice, maxPrice);
		List<Car> carsList = carRepository.findByPriceBetween(minPrice, maxPrice);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException("No Cars found with price between: " + minPrice + " and " + maxPrice);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByBrandAndColorAndAvailability(String brand, String color, boolean availability)
			throws NoDataFoundException {
		logger.info("Searching cars by brand: {}, color: {} and availability: {}", brand, color, availability);
		List<Car> carsList = carRepository.findByBrandAndColorAndAvailability(brand, color, availability);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException(
					"No Cars found with Brand: " + brand + " color: " + color + " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByPriceLessThan(double price) throws NoDataFoundException {
		logger.info("Searching cars by price less than {}", price);
		List<Car> carsList = carRepository.findByPriceLessThan(price);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException("No Cars found with Price less than: " + price);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByPriceGreaterThan(double price) throws NoDataFoundException {
		logger.info("Searching cars by price greater than {}", price);
		List<Car> carsList = carRepository.findByPriceGreaterThan(price);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException("No Cars found with Price greater than: " + price);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByTransmissionTypeAndAvailability(TransmissionType transmissionType,
			boolean availability) throws NoDataFoundException {
		logger.info("Searching cars by transmission type: {} and availability: {}", transmissionType, availability);
		List<Car> carsList = carRepository.findByTransmissionTypeAndAvailability(transmissionType, availability);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException(
					"No Cars found with TransmissionType: " + transmissionType + " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByFuelTypeAndAvailability(FuelType fuelType, boolean availability)
			throws NoDataFoundException {
		logger.info("Searching cars by fuel type: {} and availability: {}", fuelType, availability);
		List<Car> carsList = carRepository.findByFuelTypeAndAvailability(fuelType, availability);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException(
					"No Cars found with FuelType: " + fuelType + " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByBrandAndPriceBetween(String brand, double minPrice, double maxPrice)
			throws NoDataFoundException {
		logger.info("Searching cars by brand: {}, price between {} and {}", brand, minPrice, maxPrice);
		List<Car> carsList = carRepository.findByBrandAndPriceBetween(brand, minPrice, maxPrice);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException(
					"No Cars found with Brand: " + brand + " and Price between: " + minPrice + " and " + maxPrice);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	@Override
	public List<CarDTO> searchCarsByLocationAndTransmissionTypeAndAvailability(String location,
			TransmissionType transmissionType, boolean availability) throws NoDataFoundException {
		logger.info("Searching cars by location: {}, transmission type: {} and availability: {}", location,
				transmissionType, availability);
		List<Car> carsList = carRepository.findByLocationAndTransmissionTypeAndAvailability(location, transmissionType,
				availability);
		if (carsList.isEmpty()) {
			logger.warn("No Cars found matching the criteria");
			throw new NoDataFoundException("No Cars found with Location: " + location + " TransmissionType: "
					+ transmissionType + " availability: " + availability);
		}
		logger.debug("Found {} cars matching the criteria", carsList.size());
		return mapCarEntitiesToDTOs(carsList);
	}

	private List<CarDTO> mapCarEntitiesToDTOs(List<Car> cars) {
		return cars.stream().map(car -> modelMapper.map(car, CarDTO.class)).collect(Collectors.toList());
	}

	// for sorting and filtering..
	@Override
	public List<CarDTO> getAllSortedCars(String sortBy) {
		// TODO Auto-generated method stub
		List<Car> carsList = carRepository.findAll(Sort.by(sortBy));
		List<CarDTO> carDTOList = new ArrayList<>();
		for (Car car : carsList) {
			carDTOList.add(modelMapper.map(car, CarDTO.class));
		}
		logger.debug("Fetched cars: {}", carDTOList.size());
		return carDTOList;

	}

	@Override
	public List<CarDTO> getFilteredAndSortedCars(String sortBy, boolean availability, List<String> carTypes,
			List<String> fuelTypes, List<String> transmissionTypes, String location) {
		Sort sort;
		if (sortBy.equals("-price")) {
			// Sort by price in descending order
			sort = Sort.by("price").descending();
		} else if (sortBy.equals("-brand")) {
			// Sort by brand in descending order
			sort = Sort.by("brand").descending();
		} else {
			// Sort by the specified field
			sort = Sort.by(sortBy);
		}

		List<Car> cars;

		if (availability) {
			// Filter by availability and location
			if (location.isBlank() || location.isEmpty()) {
				if (!carTypes.isEmpty() && !fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by availability, car types, fuel types, and transmission types
					cars = carRepository.findByAvailabilityAndCarTypeInAndFuelTypeInAndTransmissionTypeIn(availability,
							carTypes, fuelTypes, transmissionTypes, sort);
				} else if (!carTypes.isEmpty() && !fuelTypes.isEmpty()) {
					// Fetch cars by availability, car types, and fuel types
					cars = carRepository.findByAvailabilityAndCarTypeInAndFuelTypeIn(availability, carTypes, fuelTypes,
							sort);
				} else if (!carTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by availability, car types, and transmission types
					cars = carRepository.findByAvailabilityAndCarTypeInAndTransmissionTypeIn(availability, carTypes,
							transmissionTypes, sort);
				} else if (!fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by availability, fuel types, and transmission types
					cars = carRepository.findByAvailabilityAndFuelTypeInAndTransmissionTypeIn(availability, fuelTypes,
							transmissionTypes, sort);
				} else if (!carTypes.isEmpty()) {
					// Fetch cars by availability and car types
					cars = carRepository.findByAvailabilityAndCarTypeIn(availability, carTypes, sort);
				} else if (!fuelTypes.isEmpty()) {
					// Fetch cars by availability and fuel types
					cars = carRepository.findByAvailabilityAndFuelTypeIn(availability, fuelTypes, sort);
				} else if (!transmissionTypes.isEmpty()) {
					// Fetch cars by availability and transmission types
					cars = carRepository.findByAvailabilityAndTransmissionTypeIn(availability, transmissionTypes, sort);
				} else {
					// Fetch cars only by availability
					cars = carRepository.findByAvailability(availability, sort);
				}
			} else {
				if (!carTypes.isEmpty() && !fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by availability, location, car types, fuel types, and transmission
					// types
					cars = carRepository.findByAvailabilityAndLocationAndCarTypeInAndFuelTypeInAndTransmissionTypeIn(
							availability, location, carTypes, fuelTypes, transmissionTypes, sort);
				} else if (!carTypes.isEmpty() && !fuelTypes.isEmpty()) {
					// Fetch cars by availability, location, car types, and fuel types
					cars = carRepository.findByAvailabilityAndLocationAndCarTypeInAndFuelTypeIn(availability, location,
							carTypes, fuelTypes, sort);
				} else if (!carTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by availability, location, car types, and transmission types
					cars = carRepository.findByAvailabilityAndLocationAndCarTypeInAndTransmissionTypeIn(availability,
							location, carTypes, transmissionTypes, sort);
				} else if (!fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by availability, location, fuel types, and transmission types
					cars = carRepository.findByAvailabilityAndLocationAndFuelTypeInAndTransmissionTypeIn(availability,
							location, fuelTypes, transmissionTypes, sort);
				} else if (!carTypes.isEmpty()) {
					// Fetch cars by availability, location, and car types
					cars = carRepository.findByAvailabilityAndLocationAndCarTypeIn(availability, location, carTypes,
							sort);
				} else if (!fuelTypes.isEmpty()) {
					// Fetch cars by availability, location, and fuel types
					cars = carRepository.findByAvailabilityAndLocationAndFuelTypeIn(availability, location, fuelTypes,
							sort);
				} else if (!transmissionTypes.isEmpty()) {
					// Fetch cars by availability, location, and transmission types
					cars = carRepository.findByAvailabilityAndLocationAndTransmissionTypeIn(availability, location,
							transmissionTypes, sort);
				} else {
					// Fetch cars only by availability and location
					cars = carRepository.findByAvailabilityAndLocation(availability, location, sort);
				}
			}
		} else {
			// When availability is false
			if (location.isBlank() || location.isEmpty()) {
				if (!carTypes.isEmpty() && !fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
		            // Fetch cars by car types, fuel types, and transmission types
		            cars = carRepository.findByCarTypeInAndFuelTypeInAndTransmissionTypeIn(
		                    carTypes, fuelTypes, transmissionTypes, sort);
		        } else if (!carTypes.isEmpty() && !fuelTypes.isEmpty()) {
		            // Fetch cars by car types and fuel types
		            cars = carRepository.findByCarTypeInAndFuelTypeIn(carTypes, fuelTypes, sort);
		        } else if (!carTypes.isEmpty() && !transmissionTypes.isEmpty()) {
		            // Fetch cars by car types and transmission types
		            cars = carRepository.findByCarTypeInAndTransmissionTypeIn(
		                    carTypes, transmissionTypes, sort);
		        } else if (!fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
		            // Fetch cars by fuel types and transmission types
		            cars = carRepository.findByFuelTypeInAndTransmissionTypeIn(
		                    fuelTypes, transmissionTypes, sort);
		        } else if (!carTypes.isEmpty()) {
		            // Fetch cars by car types
		            cars = carRepository.findByCarTypeIn(carTypes, sort);
		        } else if (!fuelTypes.isEmpty()) {
		            // Fetch cars by fuel types
		            cars = carRepository.findByFuelTypeIn(fuelTypes, sort);
		        } else if (!transmissionTypes.isEmpty()) {
		            // Fetch cars by transmission types
		            cars = carRepository.findByTransmissionTypeIn(transmissionTypes, sort);
		        } else {
		            // Fetch all cars regardless of any filter
		            cars = carRepository.findAll(sort);
		        }
			} else {
				if (!carTypes.isEmpty() && !fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by location, car types, fuel types, and transmission types
					cars = carRepository.findByLocationAndCarTypeInAndFuelTypeInAndTransmissionTypeIn(location,
							carTypes, fuelTypes, transmissionTypes, sort);
				} else if (!carTypes.isEmpty() && !fuelTypes.isEmpty()) {
					// Fetch cars by location, car types, and fuel types
					cars = carRepository.findByLocationAndCarTypeInAndFuelTypeIn(location, carTypes, fuelTypes, sort);
				} else if (!carTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by location, car types, and transmission types
					cars = carRepository.findByLocationAndCarTypeInAndTransmissionTypeIn(location, carTypes,
							transmissionTypes, sort);
				} else if (!fuelTypes.isEmpty() && !transmissionTypes.isEmpty()) {
					// Fetch cars by location, fuel types, and transmission types
					cars = carRepository.findByLocationAndFuelTypeInAndTransmissionTypeIn(location, fuelTypes,
							transmissionTypes, sort);
				} else if (!carTypes.isEmpty()) {
					// Fetch cars by location and car types
					cars = carRepository.findByLocationAndCarTypeIn(location, carTypes, sort);
				} else if (!fuelTypes.isEmpty()) {
					// Fetch cars by location and fuel types
					cars = carRepository.findByLocationAndFuelTypeIn(location, fuelTypes, sort);
				} else if (!transmissionTypes.isEmpty()) {
					// Fetch cars by location and transmission types
					cars = carRepository.findByLocationAndTransmissionTypeIn(location, transmissionTypes, sort);
				} else {
					// Fetch all cars regardless of any filter
					cars = carRepository.findByLocation(location, sort);
				}
			}
		}

		List<CarDTO> carDTOList = cars.stream().map(car -> modelMapper.map(car, CarDTO.class))
				.collect(Collectors.toList());
		
//		if (carDTOList.isEmpty()) {
//			logger.error("No cars found");
//			throw new NoDataFoundException("No cars found");
//		}
		logger.info(
				"Fetched cars: {}, availability: {}, carTypes: {}, fuelTypes: {}, transmissionTypes: {}, location: {}",
				carDTOList.size(), availability, carTypes, fuelTypes, transmissionTypes, location);

		return carDTOList;
	}

}
