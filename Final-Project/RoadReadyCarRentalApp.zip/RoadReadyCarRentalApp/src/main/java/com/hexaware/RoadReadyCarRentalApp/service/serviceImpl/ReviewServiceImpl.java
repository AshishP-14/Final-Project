package com.hexaware.RoadReadyCarRentalApp.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.ReviewDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Car;
import com.hexaware.RoadReadyCarRentalApp.entity.Review;
import com.hexaware.RoadReadyCarRentalApp.entity.User;
import com.hexaware.RoadReadyCarRentalApp.repository.CarRepository;
import com.hexaware.RoadReadyCarRentalApp.repository.ReviewRepository;
import com.hexaware.RoadReadyCarRentalApp.repository.UserRepository;
import com.hexaware.RoadReadyCarRentalApp.service.ReviewService;

import jakarta.transaction.Transactional;

@Service
public class ReviewServiceImpl implements ReviewService {

	private static final Logger logger = LoggerFactory.getLogger(ReservationServiceImpl.class);

	@Autowired
	private ReviewRepository reviewRepository;

	@Autowired
	private CarRepository carRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ReviewDTO createReview(ReviewDTO reviewDTO) throws ResourceNotFoundException {
		logger.info("Creating review: {}", reviewDTO);
		Car car = carRepository.findById(reviewDTO.getCarId()).orElseThrow(() -> {
			logger.error("Car not found with ID: {}", reviewDTO.getCarId());
			return new ResourceNotFoundException("Car", "id", reviewDTO.getCarId());
		});

		// Check if the referenced User exists
		User user = userRepository.findById(reviewDTO.getUserId()).orElseThrow(() -> {
			logger.error("User not found with ID: {}", reviewDTO.getUserId());
			return new ResourceNotFoundException("User", "id", reviewDTO.getUserId());
		});

		// Map the ReviewDTO to Review entity
		Review review = modelMapper.map(reviewDTO, Review.class);
		review.setCar(car);
		review.setUser(user);

		// Save the Review
		Review createdReview = reviewRepository.save(review);

		logger.debug("Review created successfully with ID: {}", createdReview.getId());
		// Map the created Review entity back to ReviewDTO and return it
		return modelMapper.map(createdReview, ReviewDTO.class);
	}

	@Override
	public ReviewDTO getReviewById(Long id) throws ResourceNotFoundException {
		logger.info("Fetching review by ID: {}", id);
		Review review = reviewRepository.findById(id).orElseThrow(() -> {
			logger.error("Review not found with ID: {}", id);
			return new ResourceNotFoundException("Review", "id", id);
		});
		logger.debug("Fetched review: {}", review);
		return modelMapper.map(review, ReviewDTO.class);
	}

	@Override
	public List<ReviewDTO> getAllReviews() throws NoDataFoundException {
		logger.info("Fetching all reviews");
		List<Review> reviews = reviewRepository.findAll();

		if (reviews.isEmpty()) {
			logger.error("No Reviews found.");
			throw new NoDataFoundException("No reviews found");
		}

		List<ReviewDTO> reviewDTOList = new ArrayList<>();

		for (Review review : reviews) {
			reviewDTOList.add(modelMapper.map(review, ReviewDTO.class));
		}
		logger.debug("Fetched reviews: {}", reviewDTOList.size());
		return reviewDTOList;

	}

	@Override
	public ReviewDTO updateReview(Long id, ReviewDTO reviewDTO) throws ResourceNotFoundException {
		logger.info("Updating review with ID: {}", id);
		Review existingReview = reviewRepository.findById(id).orElseThrow(() -> {
			logger.error("Error updating review with ID {}: ", id);
			return new ResourceNotFoundException("Review", "id", id);
		});

		// Update only the rating and comment fields
		existingReview.setRating(reviewDTO.getRating());
		existingReview.setComment(reviewDTO.getComment());

		// Save the updated review entity
		Review updatedReview = reviewRepository.save(existingReview);
		logger.debug("Review updated successfully: {}", updatedReview);
		// Map the updated review entity back to a ReviewDTO object and return it
		return modelMapper.map(updatedReview, ReviewDTO.class);

	}

	@Override
	public void deleteReview(Long id) throws ResourceNotFoundException {
		logger.info("Deleting review with ID: {}", id);
		reviewRepository.findById(id).orElseThrow(() -> {
			logger.error("Review not found with ID: {}", id);
			return new ResourceNotFoundException("Review", "id", id);
		});
		logger.debug("Review deleted successfully with ID: {}", id);
		reviewRepository.deleteById(id);

	}

	@Override
	public List<ReviewDTO> getReviewsByCarId(Long carId) throws ResourceNotFoundException {
		logger.info("Fetching reviews by Car ID: {}", carId);
		List<Review> reviewsList = reviewRepository.findByCarId(carId);
		if (reviewsList.isEmpty()) {
			logger.error("Review not found with CarID: {}", carId);
			throw new ResourceNotFoundException("Review", "carId", carId);
		}
		List<ReviewDTO> reviewDTOList = new ArrayList<>();

		for (Review reviews : reviewsList) {
			reviewDTOList.add(modelMapper.map(reviews, ReviewDTO.class));
		}
		logger.debug("Fetched reviews: {}", reviewDTOList.size());
		return reviewDTOList;
	}

	@Override
	public List<ReviewDTO> getReviewsByUserId(Long userId) throws ResourceNotFoundException {
		logger.info("Fetching reviews by User ID: {}", userId);
		List<Review> reviewsList = reviewRepository.findByUserId(userId);
		if (reviewsList.isEmpty()) {
			logger.error("Review not found with UserID: {}", userId);
			throw new ResourceNotFoundException("Review", "userId", userId);
		}
		List<ReviewDTO> reviewDTOList = new ArrayList<>();

		for (Review reviews : reviewsList) {
			reviewDTOList.add(modelMapper.map(reviews, ReviewDTO.class));
		}
		logger.debug("Fetched reviews: {}", reviewDTOList.size());
		return reviewDTOList;
	}

	@Override
	public List<ReviewDTO> getReviewsWithRatingGreaterThanEqual(int rating) throws ResourceNotFoundException {
		logger.info("Fetching reviews with rating greater than or equal to: {}", rating);
		List<Review> reviewsList = reviewRepository.findByRatingGreaterThanEqual(rating);

		if (reviewsList.isEmpty()) {
			logger.error("No reviews found matching the criteria");
			throw new ResourceNotFoundException("Review", "rating greater than or equal to ", rating);
		}

		List<ReviewDTO> reviewDTOList = new ArrayList<>();

		for (Review reviews : reviewsList) {
			reviewDTOList.add(modelMapper.map(reviews, ReviewDTO.class));
		}
		logger.debug("Fetched reviews: {}", reviewDTOList.size());
		return reviewDTOList;
	}

	@Override
	public List<ReviewDTO> searchReviewsByKeyword(String keyword) throws ResourceNotFoundException {
		logger.info("Searching reviews by keyword: {}", keyword);
		List<Review> reviewsList = reviewRepository.findByCommentContainingIgnoreCase(keyword);
		if (reviewsList.isEmpty()) {
			logger.error("No reviews found matching the criteria");
			throw new ResourceNotFoundException("Review", "keyword", keyword);
		}
		List<ReviewDTO> reviewDTOList = new ArrayList<>();

		for (Review reviews : reviewsList) {
			reviewDTOList.add(modelMapper.map(reviews, ReviewDTO.class));
		}
		logger.debug("Fetched reviews: {}", reviewDTOList.size());
		return reviewDTOList;
	}

	@Override
	public List<ReviewDTO> getReviewsByCarIdAndRatingGreaterThanEqual(Long carId, int rating) {
		logger.info("Fetching reviews by Car ID: {} and rating greater than or equal to: {}", carId, rating);
		List<Review> reviewsList = reviewRepository.findByCarIdAndRatingGreaterThanEqual(carId, rating);
		List<ReviewDTO> reviewDTOList = new ArrayList<>();

		for (Review reviews : reviewsList) {

			reviewDTOList.add(modelMapper.map(reviews, ReviewDTO.class));
		}
		logger.debug("Fetched reviews: {}", reviewDTOList.size());
		return reviewDTOList;

	}

	@Override
	public Long countReviewsByCarId(Long carId) throws ResourceNotFoundException {
		logger.info("Counting reviews by Car ID: {}", carId);
		List<Review> reviewsList = reviewRepository.findByCarId(carId);
		if (reviewsList.isEmpty()) {
			logger.error("No reviews found matching the criteria");
			throw new ResourceNotFoundException("Review", "carId", carId);
		}
		return reviewRepository.countByCarId(carId);
	}

	@Override
	@Transactional
	public void deleteReviewsByUserId(Long userId) throws ResourceNotFoundException {
		logger.info("Deleting reviews by User ID: {}", userId);
		List<Review> reviewsList = reviewRepository.findByUserId(userId);
		if (reviewsList.isEmpty()) {
			logger.error("Review not found with UserID: {}", userId);
			throw new ResourceNotFoundException("Review", "userId", userId);
		}
		logger.debug("Review deleted successfully with UserID: {}", userId);
		reviewRepository.deleteByUserId(userId);

	}

	@Override
	@Transactional
	public void deleteReviewsByCarId(Long carId) throws ResourceNotFoundException {
		logger.info("Deleting reviews by Car ID: {}", carId);
		List<Review> reviewsList = reviewRepository.findByCarId(carId);
		if (reviewsList.isEmpty()) {
			logger.error("Review not found with CarID: {}", carId);
			throw new ResourceNotFoundException("Review", "carId", carId);
		}
		logger.debug("Review deleted successfully with CarID: {}", carId);
		reviewRepository.deleteByCarId(carId);
	}

	@Override
	public Double getAverageRatingByCarId(Long carId) {
		return reviewRepository.findAverageRatingByCarId(carId);
	}
}
