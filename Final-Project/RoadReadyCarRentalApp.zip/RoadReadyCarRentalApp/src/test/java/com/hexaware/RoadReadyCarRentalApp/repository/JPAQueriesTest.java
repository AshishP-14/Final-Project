package com.hexaware.RoadReadyCarRentalApp.repository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexaware.RoadReadyCarRentalApp.entity.Car;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.CarType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.FuelType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.TransmissionType;
import com.hexaware.RoadReadyCarRentalApp.entity.Role;
import com.hexaware.RoadReadyCarRentalApp.entity.User;

@SpringBootTest
public class JPAQueriesTest {
	private static final Logger logger = LoggerFactory.getLogger(JPAQueriesTest.class);
	
	@Autowired
	private CarRepository carRepository;
	@Autowired
	private UserRepository repo;
	@Test
	void saveMethodTest() {
		Car car = new Car(null, "Maruti Suzuki", "Swift", "Red", 600000.0, true, "New Delhi", "Fuel-efficient hatchback", FuelType.PETROL, TransmissionType.MANUAL, CarType.HATCHBACK, null, null);

		Car savedCar = carRepository.save(car);
		logger.info( "save car in db using JPA save(). " + savedCar);
	}
	@Test
	void registerAdminTest() {
		User admin = new User();
		admin.setFirstName("Admin");
		admin.setLastName("User");
		admin.setEmail("admin@example.com");
		admin.setUsername("admin_user");
		admin.setPassword("Password1@");
		admin.setPhoneNumber("1234567890");

		Role adminRole = new Role();
		adminRole.setName("ROLE_ADMIN");

		Set<Role> roles = new HashSet<>();
		roles.add(adminRole);

		admin.setRoles(roles);
		
		User user = repo.save(admin);
		logger.info( "save admin in db using JPA save(). " + user);
	}
	@Test
	void saveAllTest() {
		Car car1 = new Car(null, "Hyundai", "i20", "White", 800000.0, true, "Mumbai", "Feature-packed premium hatchback", Car.FuelType.PETROL, Car.TransmissionType.MANUAL, Car.CarType.HATCHBACK, null, null);

		Car car2 = new Car(null, "Tata", "Nexon", "Blue", 900000.0, true, "Bangalore", "Compact SUV with great mileage", Car.FuelType.DIESEL, Car.TransmissionType.MANUAL, Car.CarType.SUV, null, null);

		Car car3 = new Car(null, "Honda", "City", "Silver", 1200000.0, true, "Chennai", "Luxury sedan with comfortable interiors", Car.FuelType.PETROL, Car.TransmissionType.AUTOMATIC, Car.CarType.SEDAN, null, null);

		Car car4 = new Car(null, "Mahindra", "Scorpio", "Black", 1500000.0, true, "Kolkata", "Powerful SUV for rough terrains", Car.FuelType.DIESEL, Car.TransmissionType.MANUAL, Car.CarType.SUV, null, null);

		Car car5 = new Car(null, "Maruti Suzuki", "Vitara Brezza", "Grey", 1100000.0, true, "Hyderabad", "Compact SUV with sporty looks", Car.FuelType.PETROL, Car.TransmissionType.AUTOMATIC, Car.CarType.SUV, null, null);

		Car car6 = new Car(null, "Toyota", "Innova Crysta", "Golden", 1800000.0, true, "Pune", "Spacious MPV for family outings", Car.FuelType.DIESEL, Car.TransmissionType.AUTOMATIC, Car.CarType.MUV, null, null);

		Car car7 = new Car(null, "Renault", "Kwid", "Red", 500000.0, true, "Ahmedabad", "Budget-friendly compact hatchback", Car.FuelType.PETROL, Car.TransmissionType.MANUAL, Car.CarType.HATCHBACK, null, null);

		Car car8 = new Car(null, "Ford", "EcoSport", "White", 1000000.0, true, "Jaipur", "Compact SUV with dynamic design", Car.FuelType.PETROL, Car.TransmissionType.AUTOMATIC, Car.CarType.SUV, null, null);

		Car car9 = new Car(null, "Volkswagen", "Polo", "Black", 850000.0, true, "Lucknow", "German-engineered premium hatchback", Car.FuelType.DIESEL, Car.TransmissionType.MANUAL, Car.CarType.HATCHBACK, null, null);

		Car car10 = new Car(null, "Skoda", "Octavia", "Silver", 2000000.0, true, "Chandigarh", "Elegant sedan with advanced features", Car.FuelType.PETROL, Car.TransmissionType.AUTOMATIC, Car.CarType.SEDAN, null, null);

		List<Car> savedCarList = carRepository.saveAll(List.of(car1,car2,car3,car4,car5,car6,car7,car8,car9,car10));
		logger.info( "save carlist in db using JPA save(). " + savedCarList);
	}
	
}
